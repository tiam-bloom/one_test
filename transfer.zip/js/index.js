var list = []; //存储选框中的列表
var flag = "left"; //定义标记判断是选中左边还是右边
var checklist = 0; //存储input框选中数量
//穿梭框左侧选中
//任务1:步骤2——给左侧列表中的单选框，绑定点击事件
$("#clickLeft input").click(function() {
	flag = "left";
	onCurrent(flag)
});
//穿梭框右侧选中
//任务1:步骤3——给右侧列表中的单选框，绑定点击事件
$("#clickRight input").click(function() {
	flag = "right";
	onCurrent(flag)
});

$(".toleft").on("click", function() {
	var checklist = $("#clickLeft input:checkbox:checked ");
	for (var i = 0; i < checklist.length; i++) {
		//checklist是jquery对象
		//checklist是Element节点
		checklist[i].parentElement.remove();
		$("#clickRight").prepend(checklist[i].parentElement); //移动到右边
		checklist[i].checked = false; //清除样式勾勾
	}
});
$(".toright").on("click", function() {
	var checklist = $("#clickRight input:checkbox:checked ");
	for (var i = 0; i < checklist.length; i++) {
		//checklist是jquery对象
		//checklist是Element节点
		checklist[i].parentElement.remove();
		$("#clickLeft").prepend(checklist[i].parentElement); //
		checklist[i].checked = false; //清除样式勾勾
	}
});
//判断移动按钮是否高亮显示
		function onCurrent(flag) {
			if (flag == "left") {
				//任务4：步骤1——获取左侧input框选中数量赋值给checklist
				var checklist = $("#clickLeft input:checkbox:checked ")
				if (checklist.length > 0) {
					//任务4：步骤2——为左边移动按钮添加样式“current”					
					$(".toleft").addClass("current");
				} else {
					//任务4：步骤3——为左边移动按钮删除样式“current”
					$(".toleft").removeClass("current");
				}
			} else {
				//任务4：步骤4——获取右侧input框选中数量赋值给checklist
				var checklist = $("#clickRight input:checkbox:checked ")
				if (checklist.length > 0) {
					//任务4：步骤5—为右边移动按钮添加样式“current”
					$(".toright").addClass("current");
				} else {
					//任务4：步骤6—为右边移动按钮删除样式“current”
					$(".toright").removeClass("current");
				}
			}
}